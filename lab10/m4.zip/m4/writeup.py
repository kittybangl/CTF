#!/usr/bin/env python3
# from https://cryptohack.org/challenges/introduction/

import telnetlib
import json
from typing import Tuple
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import HKDF
from Crypto.Hash import SHA256
import time
# Change this to REMOTE = False if you are running against a local instance of the server
REMOTE = False
# Remember to change the port if you are re-using this client for other challenges
PORT = 51004
if REMOTE:
    host = "aclabs.ethz.ch"
else:
    host = "localhost"

tn = telnetlib.Telnet(host, PORT)
def readline():
    return tn.read_until(b"\n")

def json_recv():
    line = readline()
    return json.loads(line.decode())

def json_send(req):
    request = json.dumps(req).encode()
    tn.write(request + b"\n")

def find_len(challenge, e, N):
    ans = 1016
    while True:
        challenge *= pow(2, e, N)
        challenge %= N
        request = {
            "command": "decrypt",
            "ctxt": hex(challenge)[2:].zfill(256)
        }
        json_send(request)
        response = json_recv()
        # print(response)
        if 'res' in response:
            # print(response)
            ans -= 1
            continue
        error = response['error']
        if 'Error:' in error:
            break
        ans -= 1
    # print(ans)
    request = {
        "command": "solve",
        "i": ans
    }
    json_send(request)
    response = json_recv()
    # print(response)
    return ans
def power(a, b, c):
    # 求 a^b mod c
    res = 1
    while b > 0:
        if b % 2 == 1:
            res = (res * a) % c
        a = (a * a) % c
        b //= 2
    return res

def extended_euclidean_algorithm(a, b):
    # 扩展欧几里得算法求 a 和 b 的最大公约数以及其系数
    if b == 0:
        return a, 1, 0
    gcd, x, y = extended_euclidean_algorithm(b, a % b)
    return gcd, y, x - (a // b) * y


def power_inverse(a, b, c):
    # 使用扩展欧几里得算法求 a 对于模数 c 的乘法逆元
    gcd, x, y = extended_euclidean_algorithm(a, c)
    if gcd != 1:
        return None  # a 对于模数 c 的乘法逆元不存在
    else:
        a_inv = x % c

    # 使用快速幂算法计算 pow(a_inv, b, c)
    res = 1
    while b > 0:
        if b % 2 == 1:
            res = (res * a_inv) % c
        a_inv = (a_inv * a_inv) % c
        b //= 2

    # 返回 pow(a_inv, b, c) 的结果
    return res


def is_above(alpha, r, challenge, e, N):

    challenge *= pow(alpha, e, N)
    challenge %= N
    challenge *= power_inverse(r, e, N)
    challenge %= N
    request = {
        "command": "decrypt",
        "ctxt": hex(challenge)[2:].zfill(256)
    }
    json_send(request)
    response = json_recv()
    if 'res' in response:
        return True
    error = response['error']
    # print(response)
    if 'Eror:' in error:
        # print(1)
        return True
    return False

def is_above_N(mid, challenge, e, N):
    # print(challenge)
    challenge *= pow(mid, e, N)
    challenge %= N
    # print(hex(challenge)[2:].zfill(256))
    request = {
        "command": "decrypt",
        "ctxt": hex(challenge)[2:].zfill(256)
    }
    json_send(request)
    response = json_recv()
    if 'res' in response:
        return True
    error = response['error']
    # print(response)
    if 'Eror:' in error:
        # print(1)
        return True
    return False

def find_a0(challenge, len, e, N):
    min = pow(2, 1024-len-1)
    max = pow(2, 1024-len+1)
    ans = 0
    for i in range(min, max):
        if is_above_N(i, challenge, e, N) == True:
            ans = i
            print(i)
            break
    return ans

def ceil (a: int , b: int ) -> int : 
# Necessary because of floating point precision loss
    return a // b + (1 if a % b != 0 else 0)
def get_multiplier ( m_max : int , m_min : int , N: int , B: int) -> int : 
    tmp = ceil (2 * B , m_max - m_min)
    r = tmp * m_min // N 
    alpha = ceil (r * N , m_min)
    return alpha

if __name__ == '__main__':
    request = {
        "command": "get_params"
    }
    json_send(request)
    response = json_recv()

    N = response['N']
    e = response['e']

    request = {
        "command": "flag"
    }
    json_send(request)
    response = json_recv()
    challenge = response['flag']
    challenge = int(challenge, 16)

    # Step 1
    len = find_len(challenge, e, N)
    print("len", len)

    # Step 2
    a0 = find_a0(challenge, len, e, N)
    print("a0", a0)
    m_min = N // a0
    m_max = N // (a0-1)
    print(m_max, m_min)


    B = 2<<1016
    alpha = get_multiplier(m_max, m_min, N, B)
    # α · mmin > rN
    r = alpha * m_min // N
    B_plus_rN = B + r*N
    print(is_above(alpha, r, challenge, e, N))


